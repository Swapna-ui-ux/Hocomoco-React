"use strict";
self["webpackHotUpdate_N_E"]("pages/index",{

/***/ "./components/Home/Howitworks.js":
/*!***************************************!*\
  !*** ./components/Home/Howitworks.js ***!
  \***************************************/
/***/ (function(module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "./node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/image */ "./node_modules/next/image.js");
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__);
/* module decorator */ module = __webpack_require__.hmd(module);
var _jsxFileName = "C:\\Users\\Swapna\\Desktop\\October-works\\hocomoco-react-app\\components\\Home\\Howitworks.js",
    _this = undefined;






var propTypes = {};
var defaultProps = {};

var Howitworks = function Howitworks() {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.Fragment, {
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("div", {
      className: "section-full p-t20 p-b30 bg-white bg-repeat square_shape2 inner-page-padding",
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("div", {
        className: "container",
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("div", {
          className: "p-b20",
          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("div", {
            className: "",
            children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("div", {
              className: "sec-title text-center",
              children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("h2", {
                className: "text-uppercase sep-line-one",
                children: "How It Works ?"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 17,
                columnNumber: 33
              }, _this), " "]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 16,
              columnNumber: 29
            }, _this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 15,
            columnNumber: 25
          }, _this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 14,
          columnNumber: 21
        }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("div", {
          className: "section-content",
          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("div", {
            className: "row",
            children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("div", {
              className: "col-md-3 col-sm-6 how-works",
              children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("div", {
                className: "mt-icon-box-wraper m-b30",
                children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("div", {
                  className: "relative icon-count-2 p-t30",
                  children: [" ", /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("span", {
                    className: "icon-count-number p-l50 p-r20",
                    children: "1"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 24,
                    columnNumber: 83
                  }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("div", {
                    className: "icon-md inline-icon m-b15 p-l40 p-r30 text-primary scale-in-center",
                    children: [" ", /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("span", {
                      className: "icon-cell",
                      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                        src: "/images/icon/requirement1.png",
                        alt: "",
                        layout: "fill"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 25,
                        columnNumber: 154
                      }, _this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 25,
                      columnNumber: 126
                    }, _this), " "]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 25,
                    columnNumber: 41
                  }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("div", {
                    className: "icon-content center p-t10 p-b0 p-l10 p-r10",
                    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("h4", {
                      className: "mt-tilte m-b25 text-center",
                      children: "Your Requirement"
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 27,
                      columnNumber: 45
                    }, _this), " "]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 26,
                    columnNumber: 41
                  }, _this)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 24,
                  columnNumber: 37
                }, _this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 23,
                columnNumber: 33
              }, _this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 22,
              columnNumber: 29
            }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("div", {
              className: "col-md-3 col-sm-6 how-works",
              children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("div", {
                className: "mt-icon-box-wraper m-b30",
                children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("div", {
                  className: "relative icon-count-2 p-t30",
                  children: [" ", /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("span", {
                    className: "icon-count-number p-l50 p-r20",
                    children: "2"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 33,
                    columnNumber: 83
                  }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("div", {
                    className: "icon-md inline-icon m-b15 p-l40 p-r30 text-primary scale-in-center",
                    children: [" ", /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("span", {
                      className: "icon-cell",
                      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                        src: "/images/icon/costestimate1.png",
                        alt: "",
                        layout: "fill"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 34,
                        columnNumber: 154
                      }, _this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 34,
                      columnNumber: 126
                    }, _this), " "]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 34,
                    columnNumber: 41
                  }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("div", {
                    className: "icon-content p-t10 p-b0 p-l10 p-r10",
                    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("h4", {
                      className: "mt-tilte m-b25 text-center",
                      children: "Cost Estimation"
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 36,
                      columnNumber: 45
                    }, _this), " "]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 35,
                    columnNumber: 41
                  }, _this)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 33,
                  columnNumber: 37
                }, _this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 32,
                columnNumber: 33
              }, _this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 31,
              columnNumber: 29
            }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("div", {
              className: "col-md-3 col-sm-6 how-works",
              children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("div", {
                className: "mt-icon-box-wraper m-b30",
                children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("div", {
                  className: "relative icon-count-2 p-t30",
                  children: [" ", /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("span", {
                    className: "icon-count-number  p-l50 p-r20",
                    children: "3"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 42,
                    columnNumber: 83
                  }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("div", {
                    className: "icon-md inline-icon m-b15 p-l40 p-r30 text-primary scale-in-center",
                    children: [" ", /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("span", {
                      className: "icon-cell",
                      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                        src: "/images/icon/schedule1.png",
                        alt: "",
                        layout: "fill"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 43,
                        columnNumber: 154
                      }, _this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 43,
                      columnNumber: 126
                    }, _this), " "]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 43,
                    columnNumber: 41
                  }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("div", {
                    className: "icon-content center p-t10 p-b0 p-l10 p-r10",
                    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("h4", {
                      className: "mt-tilte m-b25 text-center",
                      children: "Schedule Visit"
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 45,
                      columnNumber: 45
                    }, _this), " "]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 44,
                    columnNumber: 41
                  }, _this)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 42,
                  columnNumber: 37
                }, _this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 41,
                columnNumber: 33
              }, _this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 40,
              columnNumber: 29
            }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("div", {
              className: "col-md-3 col-sm-6 how-works",
              children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("div", {
                className: "mt-icon-box-wraper m-b30",
                children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("div", {
                  className: "relative icon-count-2 p-t30",
                  children: [" ", /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("span", {
                    className: "icon-count-number  p-l50 p-r20",
                    children: "4"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 51,
                    columnNumber: 83
                  }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("div", {
                    className: "icon-md inline-icon m-b15 p-l40 p-r30 text-primary scale-in-center",
                    children: [" ", /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("span", {
                      className: "icon-cell",
                      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                        src: "/images/icon/excute1.png",
                        alt: "",
                        layout: "fill"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 52,
                        columnNumber: 154
                      }, _this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 52,
                      columnNumber: 126
                    }, _this), " "]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 52,
                    columnNumber: 41
                  }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("div", {
                    className: "icon-content p-t10 p-b0 p-l10 p-r10",
                    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("h4", {
                      className: "mt-tilte m-b25 text-center",
                      children: "Work Execution"
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 54,
                      columnNumber: 45
                    }, _this), " "]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 53,
                    columnNumber: 41
                  }, _this)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 51,
                  columnNumber: 37
                }, _this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 50,
                columnNumber: 33
              }, _this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 49,
              columnNumber: 29
            }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("div", {
              className: "col-md-3 col-sm-6 how-works",
              children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("div", {
                className: "mt-icon-box-wraper m-b30",
                children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("div", {
                  className: "relative icon-count-2 p-t30",
                  children: [" ", /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("span", {
                    className: "icon-count-number  p-l50 p-r20",
                    children: "5"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 60,
                    columnNumber: 83
                  }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("div", {
                    className: "icon-md inline-icon m-b15 p-l40 p-r30 text-primary scale-in-center",
                    children: [" ", /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("span", {
                      className: "icon-cell",
                      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                        src: "/images/icon/architecture1.png",
                        alt: "",
                        layout: "fill"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 61,
                        columnNumber: 154
                      }, _this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 61,
                      columnNumber: 126
                    }, _this), " "]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 61,
                    columnNumber: 41
                  }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("div", {
                    className: "icon-content p-t10 p-b0 p-l10 p-r10",
                    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("h4", {
                      className: "mt-tilte m-b25 text-center",
                      children: "Satisfied Delivery"
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 63,
                      columnNumber: 45
                    }, _this), " "]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 62,
                    columnNumber: 41
                  }, _this)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 60,
                  columnNumber: 37
                }, _this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 59,
                columnNumber: 33
              }, _this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 58,
              columnNumber: 29
            }, _this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 21,
            columnNumber: 25
          }, _this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 20,
          columnNumber: 21
        }, _this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 13,
        columnNumber: 17
      }, _this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 12,
      columnNumber: 12
    }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("div", {
      className: "section-full needsrow",
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("div", {
        className: "container",
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("div", {
          className: "text-center needs-text",
          children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("h2", {
            children: "All your construction needs under one roof"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 75,
            columnNumber: 25
          }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("div", {
            className: "estimate",
            children: [" ", /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("a", {
              href: "",
              "data-toggle": "modal",
              "data-target": "#with-form",
              children: " Get a free estimate now"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 76,
              columnNumber: 52
            }, _this), " "]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 76,
            columnNumber: 25
          }, _this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 74,
          columnNumber: 21
        }, _this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 73,
        columnNumber: 17
      }, _this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 72,
      columnNumber: 13
    }, _this)]
  }, void 0, true);
};

_c = Howitworks;
Howitworks.propTypes = propTypes;
Howitworks.defaultProps = defaultProps;
/* harmony default export */ __webpack_exports__["default"] = (Howitworks);

var _c;

$RefreshReg$(_c, "Howitworks");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.id);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }


/***/ }),

/***/ "./components/Home/Whychooseus.js":
/*!****************************************!*\
  !*** ./components/Home/Whychooseus.js ***!
  \****************************************/
/***/ (function(module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "./node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/image */ "./node_modules/next/image.js");
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__);
/* module decorator */ module = __webpack_require__.hmd(module);
var _jsxFileName = "C:\\Users\\Swapna\\Desktop\\October-works\\hocomoco-react-app\\components\\Home\\Whychooseus.js",
    _this = undefined;






var propTypes = {};
var defaultProps = {};

var Whychooseus = function Whychooseus() {
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.Fragment, {
    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("div", {
      className: "section-full overlay-wraper bg-center bg-parallax bg-cover p-b20 p-t40 xs-hidden bg-gray-light",
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("div", {
        className: "container",
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("div", {
          className: "sec-title text-center p-b20",
          children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("h2", {
            className: "text-uppercase sep-line-one text-black",
            children: " Why Choose Us"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 15,
            columnNumber: 25
          }, _this), " "]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 14,
          columnNumber: 21
        }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("div", {
          className: "row row-pb-md",
          children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("div", {
            className: "col-md-12 padding-0",
            children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("div", {
              className: "col-md-4 whychoose-box",
              children: [" ", /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("span", {
                className: "whychoose-icon",
                children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                  alt: "Integrated Home construction and monitoring services",
                  src: "/images/icon/professional-service-icon-min.png",
                  layout: "fill"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 19,
                  columnNumber: 29
                }, _this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 18,
                columnNumber: 70
              }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("aside", {
                className: "whychoose-text",
                children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("h5", {
                  className: "margin-0",
                  children: "Professional Service"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 22,
                  columnNumber: 37
                }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("p", {
                  className: "text-left font-light",
                  children: "\u2018Best in class\u2019 service ensured with our experienced in-house Design & Construction team. Complete Hassle-free Experience from beginning to end. "
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 23,
                  columnNumber: 37
                }, _this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 21,
                columnNumber: 33
              }, _this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 18,
              columnNumber: 29
            }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("div", {
              className: "col-md-4 whychoose-box",
              children: [" ", /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("span", {
                className: "whychoose-icon",
                children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                  alt: "Wide range of Construction and monitoring services",
                  src: "/images/icon/insured-work-icon-min.png",
                  layout: "fill"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 27,
                  columnNumber: 29
                }, _this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 26,
                columnNumber: 70
              }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("aside", {
                className: "whychoose-text",
                children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("h5", {
                  className: "margin-0",
                  children: "Insured Work"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 30,
                  columnNumber: 37
                }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("p", {
                  className: "text-left font-light",
                  children: "Your Structure is insured with us. Any issue- post construction, no need to worry. We have your back; we are always available at a click/call away. "
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 31,
                  columnNumber: 37
                }, _this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 29,
                columnNumber: 33
              }, _this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 26,
              columnNumber: 29
            }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("div", {
              className: "col-md-4 whychoose-box",
              children: [" ", /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("span", {
                className: "whychoose-icon",
                children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                  alt: "Integrated Home construction and monitoring services",
                  src: "/images/icon/digital-tracking-icon-min.png",
                  layout: "fill"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 35,
                  columnNumber: 29
                }, _this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 34,
                columnNumber: 70
              }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("aside", {
                className: "whychoose-text",
                children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("h5", {
                  className: "margin-0",
                  children: "100% transparency "
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 38,
                  columnNumber: 37
                }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("p", {
                  className: "text-left font-light",
                  children: "No Hidden Charges, Every detail is as clear as a crystal. To bring in transparency is one of our core purposes of existence. "
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 39,
                  columnNumber: 37
                }, _this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 37,
                columnNumber: 33
              }, _this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 34,
              columnNumber: 29
            }, _this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 17,
            columnNumber: 25
          }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("div", {
            className: "col-md-12 mt-15 padding-0",
            children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("div", {
              className: "col-md-4 whychoose-box",
              children: [" ", /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("span", {
                className: "whychoose-icon",
                children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                  alt: "End to End Construction Services",
                  src: "/images/icon/transparency-icon-min.png",
                  layout: "fill"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 45,
                  columnNumber: 29
                }, _this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 44,
                columnNumber: 70
              }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("aside", {
                className: "whychoose-text",
                children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("h5", {
                  className: "margin-0",
                  children: "Digital Tracking"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 48,
                  columnNumber: 37
                }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("p", {
                  className: "text-left font-light",
                  children: "You can now digitally track your work progress, with a simple login you are empowered to control and track every inch of your work site. "
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 49,
                  columnNumber: 37
                }, _this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 47,
                columnNumber: 33
              }, _this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 44,
              columnNumber: 29
            }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("div", {
              className: "col-md-4 whychoose-box",
              children: [" ", /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("span", {
                className: "whychoose-icon",
                children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                  alt: "Integrated Home construction and monitoring services",
                  src: "/images/icon/quality-assurance-icon-min.png",
                  layout: "fill"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 53,
                  columnNumber: 29
                }, _this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 52,
                columnNumber: 70
              }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("aside", {
                className: "whychoose-text",
                children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("h5", {
                  className: "margin-0",
                  children: "Quality Assurance"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 56,
                  columnNumber: 37
                }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("p", {
                  className: "text-left font-light",
                  children: "Be ensured with us that you have the \u2018right quality for the right price\u2019. No more over charging and no more substandard products."
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 57,
                  columnNumber: 37
                }, _this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 55,
                columnNumber: 33
              }, _this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 52,
              columnNumber: 29
            }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("div", {
              className: "col-md-4 whychoose-box",
              children: [" ", /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("span", {
                className: "whychoose-icon",
                children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                  alt: "Wide range of Construction and monitoring services",
                  src: "/images/icon/on-time-delivery-icon.png",
                  layout: "fill"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 61,
                  columnNumber: 29
                }, _this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 60,
                columnNumber: 70
              }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("aside", {
                className: "whychoose-text",
                children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("h5", {
                  className: "margin-0",
                  children: "On time Delivery"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 64,
                  columnNumber: 37
                }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("p", {
                  className: "text-left font-light",
                  children: "Missing deadline? Not in our dictionary, we are \u2018on time every time\u2019. We will ensure \u2018on time delivery\u2019 thus ensuring that there are no cost over runs. "
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 65,
                  columnNumber: 37
                }, _this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 63,
                columnNumber: 33
              }, _this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 60,
              columnNumber: 29
            }, _this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 43,
            columnNumber: 25
          }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("div", {
            className: "col-md-12 mt-15 padding-0",
            children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("div", {
              className: "col-md-4 whychoose-box",
              children: [" ", /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("span", {
                className: "whychoose-icon",
                children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                  alt: "Wide range of Construction and monitoring services",
                  src: "/images/icon/flexible.png",
                  layout: "fill"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 71,
                  columnNumber: 29
                }, _this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 70,
                columnNumber: 70
              }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("aside", {
                className: "whychoose-text",
                children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("h5", {
                  className: "margin-0",
                  children: "Flexible Pricing Models"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 74,
                  columnNumber: 37
                }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("p", {
                  className: "text-left font-light",
                  children: "Quotes that are tailored fit to your choice. Not happy with rigid pricing models, we understand your frustration. With us, you can customize as per your convenience. "
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 75,
                  columnNumber: 37
                }, _this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 73,
                columnNumber: 33
              }, _this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 70,
              columnNumber: 29
            }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("div", {
              className: "col-md-4 whychoose-box",
              children: [" ", /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("span", {
                className: "whychoose-icon",
                children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                  alt: "Wide range of Construction and monitoring services",
                  src: "/images/icon/curbing.png",
                  layout: "fill"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 79,
                  columnNumber: 29
                }, _this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 78,
                columnNumber: 70
              }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("aside", {
                className: "whychoose-text",
                children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("h5", {
                  className: "margin-0",
                  children: "Curbing Malpractices"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 82,
                  columnNumber: 37
                }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("p", {
                  className: "text-left font-light",
                  children: "We have put a check on Malpractices. With our new age technology assistance, we have curbed all the Fraudulent practices. "
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 83,
                  columnNumber: 37
                }, _this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 81,
                columnNumber: 33
              }, _this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 78,
              columnNumber: 29
            }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("div", {
              className: "col-md-4 whychoose-box",
              children: [" ", /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("span", {
                className: "whychoose-icon",
                children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                  alt: "Wide range of Construction and monitoring services",
                  src: "/images/icon/nocostruns.png",
                  layout: "fill"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 87,
                  columnNumber: 29
                }, _this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 86,
                columnNumber: 70
              }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("aside", {
                className: "whychoose-text",
                children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("h5", {
                  className: "margin-0",
                  children: "No Cost Over Runs"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 90,
                  columnNumber: 37
                }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("p", {
                  className: "text-left font-light",
                  children: "Once we finalize on a Quote, there is no going back. We promise you a 100% No Cost Overrun Policy. "
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 91,
                  columnNumber: 37
                }, _this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 89,
                columnNumber: 33
              }, _this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 86,
              columnNumber: 29
            }, _this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 69,
            columnNumber: 25
          }, _this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 16,
          columnNumber: 21
        }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("div", {
          className: "row read-more-less",
          "data-id": "0",
          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("div", {
            className: "col-sm-12 read-toggle readmore_sec",
            "data-id": "0",
            children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("div", {
              className: "col-md-12",
              children: [" ", /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("span", {
                className: "readmore_dsn",
                children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("i", {
                  className: "fa fa-long-arrow-right"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 100,
                  columnNumber: 35
                }, _this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 99,
                columnNumber: 57
              }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("aside", {
                className: "readmore-text",
                children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("p", {
                  className: "text-left font-light",
                  children: ["Residential Construction: Complete end to end construction services- beginning with legal permissions from Govt. authorities to designing (Architecture and Structural), execution (construction) , Interiors and monitoring services for \u2018your dream home\u2019", /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("br", {}, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 104,
                    columnNumber: 41
                  }, _this), " We understand the stress and chaos that goes through the process of building your beautiful home, although the end results are amazing, the construction journey is hectic and not very pleasant. "]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 103,
                  columnNumber: 37
                }, _this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 102,
                columnNumber: 33
              }, _this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 99,
              columnNumber: 29
            }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("div", {
              className: "col-md-12",
              children: [" ", /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("span", {
                className: "readmore_dsn",
                children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("i", {
                  className: "fa fa-long-arrow-right"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 108,
                  columnNumber: 35
                }, _this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 107,
                columnNumber: 57
              }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("aside", {
                className: "readmore-text",
                children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("p", {
                  className: "text-left font-light",
                  children: " In today\u2019s modern and fast life, home/apartment construction has become a very time consuming process but we are here to assist you build your home/apartment faster, prettier and also easier."
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 111,
                  columnNumber: 37
                }, _this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 110,
                columnNumber: 33
              }, _this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 107,
              columnNumber: 29
            }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("div", {
              className: "col-md-12",
              children: [" ", /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("span", {
                className: "readmore_dsn",
                children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("i", {
                  className: "fa fa-long-arrow-right"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 115,
                  columnNumber: 35
                }, _this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 114,
                columnNumber: 57
              }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("aside", {
                className: "readmore-text",
                children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("p", {
                  className: "text-left font-light",
                  children: "We have built this web place for you based on 4T\u2019s (our principles)"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 118,
                  columnNumber: 37
                }, _this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 117,
                columnNumber: 33
              }, _this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 114,
              columnNumber: 29
            }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("div", {
              className: "col-md-12",
              children: [" ", /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("span", {
                className: "readmore_dsn",
                children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("i", {
                  className: "fa fa-long-arrow-right"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 122,
                  columnNumber: 35
                }, _this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 121,
                columnNumber: 57
              }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("aside", {
                className: "readmore-text",
                children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("p", {
                  className: "text-left font-light",
                  children: "Transparency (we are putting an end to endless cheating)"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 125,
                  columnNumber: 37
                }, _this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 124,
                columnNumber: 33
              }, _this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 121,
              columnNumber: 29
            }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("div", {
              className: "col-md-12",
              children: [" ", /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("span", {
                className: "readmore_dsn",
                children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("i", {
                  className: "fa fa-long-arrow-right"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 129,
                  columnNumber: 35
                }, _this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 128,
                columnNumber: 57
              }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("aside", {
                className: "readmore-text",
                children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("p", {
                  className: "text-left font-light",
                  children: "Time (On time delivery, no more cost over runs due to delay in home construction)"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 132,
                  columnNumber: 37
                }, _this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 131,
                columnNumber: 33
              }, _this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 128,
              columnNumber: 29
            }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("div", {
              className: "col-md-12",
              children: [" ", /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("span", {
                className: "readmore_dsn",
                children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("i", {
                  className: "fa fa-long-arrow-right"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 136,
                  columnNumber: 35
                }, _this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 135,
                columnNumber: 57
              }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("aside", {
                className: "readmore-text",
                children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("p", {
                  className: "text-left font-light",
                  children: "Tracking (you should be able to control and track every bit of your construction, be it material or workforce, we have built necessary tools to assist you)"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 139,
                  columnNumber: 37
                }, _this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 138,
                columnNumber: 33
              }, _this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 135,
              columnNumber: 29
            }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("div", {
              className: "col-md-12",
              children: [" ", /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("span", {
                className: "readmore_dsn",
                children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("i", {
                  className: "fa fa-long-arrow-right"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 143,
                  columnNumber: 35
                }, _this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 142,
                columnNumber: 57
              }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("aside", {
                className: "readmore-text",
                children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("p", {
                  className: "text-left font-light",
                  children: "Technology (Use of technology in planning, executing and monitoring will increase efficiency, reduce cost and allow us to produce great results for you)"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 146,
                  columnNumber: 37
                }, _this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 145,
                columnNumber: 33
              }, _this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 142,
              columnNumber: 29
            }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("div", {
              className: "col-md-12",
              children: [" ", /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("span", {
                className: "readmore_dsn",
                children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("i", {
                  className: "fa fa-long-arrow-right"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 150,
                  columnNumber: 35
                }, _this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 149,
                columnNumber: 57
              }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("aside", {
                className: "readmore-text",
                children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("p", {
                  className: "text-left font-light",
                  children: "We are here to facilitate and execute end to end services on your behalf while taking into account your each preference in detail and making it the \u2018best from better\u2019 while you can monitor from your home."
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 153,
                  columnNumber: 37
                }, _this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 152,
                columnNumber: 33
              }, _this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 149,
              columnNumber: 29
            }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("div", {
              className: "col-md-12",
              children: [" ", /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("span", {
                className: "readmore_dsn",
                children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("i", {
                  className: "fa fa-long-arrow-right"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 157,
                  columnNumber: 35
                }, _this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 156,
                columnNumber: 57
              }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("aside", {
                className: "readmore-text",
                children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("p", {
                  className: "text-left font-light",
                  children: "You can be assured with us that you have the right quality for the right price, the best consultants, right professionals and in the end \u2018the best home\u2019 assurance"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 160,
                  columnNumber: 37
                }, _this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 159,
                columnNumber: 33
              }, _this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 156,
              columnNumber: 29
            }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("div", {
              className: "col-md-12",
              children: [" ", /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("span", {
                className: "readmore_dsn",
                children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("i", {
                  className: "fa fa-long-arrow-right"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 164,
                  columnNumber: 35
                }, _this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 163,
                columnNumber: 57
              }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("aside", {
                className: "readmore-text",
                children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("p", {
                  className: "text-left font-light",
                  children: " Our aim is to make this web place as one stop solution for your complete home construction beginning with architecture (Home designing) and assisting you to get necessary building permissions as we help you Build your home / Build my house."
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 167,
                  columnNumber: 37
                }, _this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 166,
                columnNumber: 33
              }, _this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 163,
              columnNumber: 29
            }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("div", {
              className: "col-md-12",
              children: [" ", /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("span", {
                className: "readmore_dsn",
                children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("i", {
                  className: "fa fa-long-arrow-right"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 171,
                  columnNumber: 35
                }, _this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 170,
                columnNumber: 57
              }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("aside", {
                className: "readmore-text",
                children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxDEV)("p", {
                  className: "text-left font-light",
                  children: " We have highly experienced professionals/Building contractors to help assist you at all stages throughout the process."
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 174,
                  columnNumber: 37
                }, _this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 173,
                columnNumber: 33
              }, _this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 170,
              columnNumber: 29
            }, _this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 98,
            columnNumber: 25
          }, _this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 97,
          columnNumber: 21
        }, _this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 13,
        columnNumber: 17
      }, _this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 12,
      columnNumber: 12
    }, _this)
  }, void 0, false);
};

_c = Whychooseus;
Whychooseus.propTypes = propTypes;
Whychooseus.defaultProps = defaultProps;
/* harmony default export */ __webpack_exports__["default"] = (Whychooseus);

var _c;

$RefreshReg$(_c, "Whychooseus");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.id);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }


/***/ })

});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvaW5kZXguNjY5MjBjM2Q4NWE5ODM5NzI3MzUuaG90LXVwZGF0ZS5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBOzs7QUFFQSxJQUFNRyxTQUFTLEdBQUcsRUFBbEI7QUFFQSxJQUFNQyxZQUFZLEdBQUcsRUFBckI7O0FBRUEsSUFBTUMsVUFBVSxHQUFHLFNBQWJBLFVBQWEsR0FBTTtBQUNyQixzQkFDSTtBQUFBLDRCQUNHO0FBQUssZUFBUyxFQUFDLDhFQUFmO0FBQUEsNkJBQ0s7QUFBSyxpQkFBUyxFQUFDLFdBQWY7QUFBQSxnQ0FDSTtBQUFLLG1CQUFTLEVBQUMsT0FBZjtBQUFBLGlDQUNJO0FBQUsscUJBQVMsRUFBQyxFQUFmO0FBQUEsbUNBQ0k7QUFBSyx1QkFBUyxFQUFDLHVCQUFmO0FBQUEsc0NBQ0k7QUFBSSx5QkFBUyxFQUFDLDZCQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQURKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQURKLGVBT0k7QUFBSyxtQkFBUyxFQUFDLGlCQUFmO0FBQUEsaUNBQ0k7QUFBSyxxQkFBUyxFQUFDLEtBQWY7QUFBQSxvQ0FDSTtBQUFLLHVCQUFTLEVBQUMsNkJBQWY7QUFBQSxxQ0FDSTtBQUFLLHlCQUFTLEVBQUMsMEJBQWY7QUFBQSx1Q0FDSTtBQUFLLDJCQUFTLEVBQUMsNkJBQWY7QUFBQSwrQ0FBOEM7QUFBTSw2QkFBUyxFQUFDLCtCQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBOUMsZUFDSTtBQUFLLDZCQUFTLEVBQUMsb0VBQWY7QUFBQSxpREFBcUY7QUFBTSwrQkFBUyxFQUFDLFdBQWhCO0FBQUEsNkNBQTRCLDhEQUFDLG1EQUFEO0FBQU8sMkJBQUcsRUFBQywrQkFBWDtBQUEyQywyQkFBRyxFQUFDLEVBQS9DO0FBQWtELDhCQUFNLEVBQUM7QUFBekQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFyRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBREosZUFFSTtBQUFLLDZCQUFTLEVBQUMsNENBQWY7QUFBQSw0Q0FDSTtBQUFJLCtCQUFTLEVBQUMsNEJBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBREo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUZKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQURKLGVBVUk7QUFBSyx1QkFBUyxFQUFDLDZCQUFmO0FBQUEscUNBQ0k7QUFBSyx5QkFBUyxFQUFDLDBCQUFmO0FBQUEsdUNBQ0k7QUFBSywyQkFBUyxFQUFDLDZCQUFmO0FBQUEsK0NBQThDO0FBQU0sNkJBQVMsRUFBQywrQkFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQTlDLGVBQ0k7QUFBSyw2QkFBUyxFQUFDLG9FQUFmO0FBQUEsaURBQXFGO0FBQU0sK0JBQVMsRUFBQyxXQUFoQjtBQUFBLDZDQUE0Qiw4REFBQyxtREFBRDtBQUFPLDJCQUFHLEVBQUMsZ0NBQVg7QUFBNEMsMkJBQUcsRUFBQyxFQUFoRDtBQUFtRCw4QkFBTSxFQUFDO0FBQTFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBckY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQURKLGVBRUk7QUFBSyw2QkFBUyxFQUFDLHFDQUFmO0FBQUEsNENBQ0k7QUFBSSwrQkFBUyxFQUFDLDRCQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQURKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFGSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFWSixlQW1CSTtBQUFLLHVCQUFTLEVBQUMsNkJBQWY7QUFBQSxxQ0FDSTtBQUFLLHlCQUFTLEVBQUMsMEJBQWY7QUFBQSx1Q0FDSTtBQUFLLDJCQUFTLEVBQUMsNkJBQWY7QUFBQSwrQ0FBOEM7QUFBTSw2QkFBUyxFQUFDLGdDQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBOUMsZUFDSTtBQUFLLDZCQUFTLEVBQUMsb0VBQWY7QUFBQSxpREFBcUY7QUFBTSwrQkFBUyxFQUFDLFdBQWhCO0FBQUEsNkNBQTRCLDhEQUFDLG1EQUFEO0FBQU8sMkJBQUcsRUFBQyw0QkFBWDtBQUF3QywyQkFBRyxFQUFDLEVBQTVDO0FBQStDLDhCQUFNLEVBQUM7QUFBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFyRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBREosZUFFSTtBQUFLLDZCQUFTLEVBQUMsNENBQWY7QUFBQSw0Q0FDSTtBQUFJLCtCQUFTLEVBQUMsNEJBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBREo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUZKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQW5CSixlQTRCSTtBQUFLLHVCQUFTLEVBQUMsNkJBQWY7QUFBQSxxQ0FDSTtBQUFLLHlCQUFTLEVBQUMsMEJBQWY7QUFBQSx1Q0FDSTtBQUFLLDJCQUFTLEVBQUMsNkJBQWY7QUFBQSwrQ0FBOEM7QUFBTSw2QkFBUyxFQUFDLGdDQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBOUMsZUFDSTtBQUFLLDZCQUFTLEVBQUMsb0VBQWY7QUFBQSxpREFBcUY7QUFBTSwrQkFBUyxFQUFDLFdBQWhCO0FBQUEsNkNBQTRCLDhEQUFDLG1EQUFEO0FBQU8sMkJBQUcsRUFBQywwQkFBWDtBQUFzQywyQkFBRyxFQUFDLEVBQTFDO0FBQTZDLDhCQUFNLEVBQUM7QUFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFyRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBREosZUFFSTtBQUFLLDZCQUFTLEVBQUMscUNBQWY7QUFBQSw0Q0FDSTtBQUFJLCtCQUFTLEVBQUMsNEJBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBREo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUZKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQTVCSixlQXFDSTtBQUFLLHVCQUFTLEVBQUMsNkJBQWY7QUFBQSxxQ0FDSTtBQUFLLHlCQUFTLEVBQUMsMEJBQWY7QUFBQSx1Q0FDSTtBQUFLLDJCQUFTLEVBQUMsNkJBQWY7QUFBQSwrQ0FBOEM7QUFBTSw2QkFBUyxFQUFDLGdDQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBOUMsZUFDSTtBQUFLLDZCQUFTLEVBQUMsb0VBQWY7QUFBQSxpREFBcUY7QUFBTSwrQkFBUyxFQUFDLFdBQWhCO0FBQUEsNkNBQTRCLDhEQUFDLG1EQUFEO0FBQU8sMkJBQUcsRUFBQyxnQ0FBWDtBQUE0QywyQkFBRyxFQUFDLEVBQWhEO0FBQW1ELDhCQUFNLEVBQUM7QUFBMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUFyRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBREosZUFFSTtBQUFLLDZCQUFTLEVBQUMscUNBQWY7QUFBQSw0Q0FDSTtBQUFJLCtCQUFTLEVBQUMsNEJBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBREo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUZKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQXJDSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVBKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURMO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFESCxlQTZESTtBQUFLLGVBQVMsRUFBQyx1QkFBZjtBQUFBLDZCQUNJO0FBQUssaUJBQVMsRUFBQyxXQUFmO0FBQUEsK0JBQ0k7QUFBSyxtQkFBUyxFQUFDLHdCQUFmO0FBQUEsa0NBQ0k7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBREosZUFFSTtBQUFLLHFCQUFTLEVBQUMsVUFBZjtBQUFBLHlDQUEyQjtBQUFHLGtCQUFJLEVBQUMsRUFBUjtBQUFXLDZCQUFZLE9BQXZCO0FBQStCLDZCQUFZLFlBQTNDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUE3REo7QUFBQSxrQkFESjtBQXlFSCxDQTFFRDs7S0FBTUE7QUE0RU5BLFVBQVUsQ0FBQ0YsU0FBWCxHQUF1QkEsU0FBdkI7QUFDQUUsVUFBVSxDQUFDRCxZQUFYLEdBQTBCQSxZQUExQjtBQUdBLCtEQUFlQyxVQUFmOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3hGQTtBQUNBO0FBQ0E7OztBQUVBLElBQU1GLFNBQVMsR0FBRyxFQUFsQjtBQUVBLElBQU1DLFlBQVksR0FBRyxFQUFyQjs7QUFFQSxJQUFNRSxXQUFXLEdBQUcsU0FBZEEsV0FBYyxHQUFNO0FBQ3RCLHNCQUNJO0FBQUEsMkJBQ0c7QUFBSyxlQUFTLEVBQUMsZ0dBQWY7QUFBQSw2QkFDSztBQUFLLGlCQUFTLEVBQUMsV0FBZjtBQUFBLGdDQUNJO0FBQUssbUJBQVMsRUFBQyw2QkFBZjtBQUFBLGtDQUNJO0FBQUkscUJBQVMsRUFBQyx3Q0FBZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFESjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBREosZUFHSTtBQUFLLG1CQUFTLEVBQUMsZUFBZjtBQUFBLGtDQUNJO0FBQUsscUJBQVMsRUFBQyxxQkFBZjtBQUFBLG9DQUNJO0FBQUssdUJBQVMsRUFBQyx3QkFBZjtBQUFBLDJDQUF5QztBQUFNLHlCQUFTLEVBQUMsZ0JBQWhCO0FBQUEsdUNBQ3pDLDhEQUFDLG1EQUFEO0FBQVEscUJBQUcsRUFBQyxzREFBWjtBQUFtRSxxQkFBRyxFQUFFLGdEQUF4RTtBQUEwSCx3QkFBTSxFQUFDO0FBQWpJO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFEeUM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBekMsZUFHSTtBQUFPLHlCQUFTLEVBQUMsZ0JBQWpCO0FBQUEsd0NBQ0k7QUFBSSwyQkFBUyxFQUFDLFVBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBREosZUFFSTtBQUFHLDJCQUFTLEVBQUMsc0JBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUhKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFESixlQVNJO0FBQUssdUJBQVMsRUFBQyx3QkFBZjtBQUFBLDJDQUF5QztBQUFNLHlCQUFTLEVBQUMsZ0JBQWhCO0FBQUEsdUNBQ3pDLDhEQUFDLG1EQUFEO0FBQVEscUJBQUcsRUFBQyxvREFBWjtBQUFpRSxxQkFBRyxFQUFDLHdDQUFyRTtBQUE4Ryx3QkFBTSxFQUFDO0FBQXJIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFEeUM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBekMsZUFHSTtBQUFPLHlCQUFTLEVBQUMsZ0JBQWpCO0FBQUEsd0NBQ0k7QUFBSSwyQkFBUyxFQUFDLFVBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBREosZUFFSTtBQUFHLDJCQUFTLEVBQUMsc0JBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUhKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFUSixlQWlCSTtBQUFLLHVCQUFTLEVBQUMsd0JBQWY7QUFBQSwyQ0FBeUM7QUFBTSx5QkFBUyxFQUFDLGdCQUFoQjtBQUFBLHVDQUN6Qyw4REFBQyxtREFBRDtBQUFRLHFCQUFHLEVBQUMsc0RBQVo7QUFBbUUscUJBQUcsRUFBQyw0Q0FBdkU7QUFBb0gsd0JBQU0sRUFBQztBQUEzSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBRHlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXpDLGVBR0k7QUFBTyx5QkFBUyxFQUFDLGdCQUFqQjtBQUFBLHdDQUNJO0FBQUksMkJBQVMsRUFBQyxVQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQURKLGVBRUk7QUFBRywyQkFBUyxFQUFDLHNCQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUZKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFISjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBakJKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFESixlQTJCSTtBQUFLLHFCQUFTLEVBQUMsMkJBQWY7QUFBQSxvQ0FDSTtBQUFLLHVCQUFTLEVBQUMsd0JBQWY7QUFBQSwyQ0FBeUM7QUFBTSx5QkFBUyxFQUFDLGdCQUFoQjtBQUFBLHVDQUN6Qyw4REFBQyxtREFBRDtBQUFRLHFCQUFHLEVBQUMsa0NBQVo7QUFBK0MscUJBQUcsRUFBQyx3Q0FBbkQ7QUFBNEYsd0JBQU0sRUFBQztBQUFuRztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBRHlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXpDLGVBR0k7QUFBTyx5QkFBUyxFQUFDLGdCQUFqQjtBQUFBLHdDQUNJO0FBQUksMkJBQVMsRUFBQyxVQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQURKLGVBRUk7QUFBRywyQkFBUyxFQUFDLHNCQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUZKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFISjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBREosZUFTSTtBQUFLLHVCQUFTLEVBQUMsd0JBQWY7QUFBQSwyQ0FBeUM7QUFBTSx5QkFBUyxFQUFDLGdCQUFoQjtBQUFBLHVDQUN6Qyw4REFBQyxtREFBRDtBQUFRLHFCQUFHLEVBQUMsc0RBQVo7QUFBbUUscUJBQUcsRUFBQyw2Q0FBdkU7QUFBcUgsd0JBQU0sRUFBQztBQUE1SDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBRHlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXpDLGVBR0k7QUFBTyx5QkFBUyxFQUFDLGdCQUFqQjtBQUFBLHdDQUNJO0FBQUksMkJBQVMsRUFBQyxVQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQURKLGVBRUk7QUFBRywyQkFBUyxFQUFDLHNCQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUZKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFISjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBVEosZUFpQkk7QUFBSyx1QkFBUyxFQUFDLHdCQUFmO0FBQUEsMkNBQXlDO0FBQU0seUJBQVMsRUFBQyxnQkFBaEI7QUFBQSx1Q0FDekMsOERBQUMsbURBQUQ7QUFBUSxxQkFBRyxFQUFDLG9EQUFaO0FBQWlFLHFCQUFHLEVBQUMsd0NBQXJFO0FBQThHLHdCQUFNLEVBQUM7QUFBckg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUR5QztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUF6QyxlQUdJO0FBQU8seUJBQVMsRUFBQyxnQkFBakI7QUFBQSx3Q0FDSTtBQUFJLDJCQUFTLEVBQUMsVUFBZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFESixlQUVJO0FBQUcsMkJBQVMsRUFBQyxzQkFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFGSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBSEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWpCSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBM0JKLGVBcURJO0FBQUsscUJBQVMsRUFBQywyQkFBZjtBQUFBLG9DQUNJO0FBQUssdUJBQVMsRUFBQyx3QkFBZjtBQUFBLDJDQUF5QztBQUFNLHlCQUFTLEVBQUMsZ0JBQWhCO0FBQUEsdUNBQ3pDLDhEQUFDLG1EQUFEO0FBQVEscUJBQUcsRUFBQyxvREFBWjtBQUFpRSxxQkFBRyxFQUFDLDJCQUFyRTtBQUFpRyx3QkFBTSxFQUFDO0FBQXhHO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFEeUM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBekMsZUFHSTtBQUFPLHlCQUFTLEVBQUMsZ0JBQWpCO0FBQUEsd0NBQ0k7QUFBSSwyQkFBUyxFQUFDLFVBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBREosZUFFSTtBQUFHLDJCQUFTLEVBQUMsc0JBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUhKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFESixlQVNJO0FBQUssdUJBQVMsRUFBQyx3QkFBZjtBQUFBLDJDQUF5QztBQUFNLHlCQUFTLEVBQUMsZ0JBQWhCO0FBQUEsdUNBQ3pDLDhEQUFDLG1EQUFEO0FBQVEscUJBQUcsRUFBQyxvREFBWjtBQUFpRSxxQkFBRyxFQUFDLDBCQUFyRTtBQUFnRyx3QkFBTSxFQUFDO0FBQXZHO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFEeUM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBekMsZUFHSTtBQUFPLHlCQUFTLEVBQUMsZ0JBQWpCO0FBQUEsd0NBQ0k7QUFBSSwyQkFBUyxFQUFDLFVBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBREosZUFFSTtBQUFHLDJCQUFTLEVBQUMsc0JBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUhKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFUSixlQWlCSTtBQUFLLHVCQUFTLEVBQUMsd0JBQWY7QUFBQSwyQ0FBeUM7QUFBTSx5QkFBUyxFQUFDLGdCQUFoQjtBQUFBLHVDQUN6Qyw4REFBQyxtREFBRDtBQUFRLHFCQUFHLEVBQUMsb0RBQVo7QUFBaUUscUJBQUcsRUFBQyw2QkFBckU7QUFBbUcsd0JBQU0sRUFBQztBQUExRztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBRHlDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQXpDLGVBR0k7QUFBTyx5QkFBUyxFQUFDLGdCQUFqQjtBQUFBLHdDQUNJO0FBQUksMkJBQVMsRUFBQyxVQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQURKLGVBRUk7QUFBRywyQkFBUyxFQUFDLHNCQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUZKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFISjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBakJKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFyREo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUhKLGVBb0ZJO0FBQUssbUJBQVMsRUFBQyxvQkFBZjtBQUFvQyxxQkFBUSxHQUE1QztBQUFBLGlDQUNJO0FBQUsscUJBQVMsRUFBQyxvQ0FBZjtBQUFvRCx1QkFBUSxHQUE1RDtBQUFBLG9DQUNJO0FBQUssdUJBQVMsRUFBQyxXQUFmO0FBQUEsMkNBQTRCO0FBQU0seUJBQVMsRUFBQyxjQUFoQjtBQUFBLHVDQUN0QjtBQUFHLDJCQUFTLEVBQUM7QUFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBRHNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTVCLGVBR0k7QUFBTyx5QkFBUyxFQUFDLGVBQWpCO0FBQUEsdUNBQ0k7QUFBRywyQkFBUyxFQUFDLHNCQUFiO0FBQUEsbVRBQ0k7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFESjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUhKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFESixlQVNJO0FBQUssdUJBQVMsRUFBQyxXQUFmO0FBQUEsMkNBQTRCO0FBQU0seUJBQVMsRUFBQyxjQUFoQjtBQUFBLHVDQUN0QjtBQUFHLDJCQUFTLEVBQUM7QUFBYjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBRHNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQTVCLGVBR0k7QUFBTyx5QkFBUyxFQUFDLGVBQWpCO0FBQUEsdUNBQ0k7QUFBRywyQkFBUyxFQUFDLHNCQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFISjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBVEosZUFnQkk7QUFBSyx1QkFBUyxFQUFDLFdBQWY7QUFBQSwyQ0FBNEI7QUFBTSx5QkFBUyxFQUFDLGNBQWhCO0FBQUEsdUNBQ3RCO0FBQUcsMkJBQVMsRUFBQztBQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFEc0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBNUIsZUFHSTtBQUFPLHlCQUFTLEVBQUMsZUFBakI7QUFBQSx1Q0FDSTtBQUFHLDJCQUFTLEVBQUMsc0JBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUhKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFoQkosZUF1Qkk7QUFBSyx1QkFBUyxFQUFDLFdBQWY7QUFBQSwyQ0FBNEI7QUFBTSx5QkFBUyxFQUFDLGNBQWhCO0FBQUEsdUNBQ3RCO0FBQUcsMkJBQVMsRUFBQztBQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFEc0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBNUIsZUFHSTtBQUFPLHlCQUFTLEVBQUMsZUFBakI7QUFBQSx1Q0FDSTtBQUFHLDJCQUFTLEVBQUMsc0JBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUhKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkF2QkosZUE4Qkk7QUFBSyx1QkFBUyxFQUFDLFdBQWY7QUFBQSwyQ0FBNEI7QUFBTSx5QkFBUyxFQUFDLGNBQWhCO0FBQUEsdUNBQ3RCO0FBQUcsMkJBQVMsRUFBQztBQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFEc0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBNUIsZUFHSTtBQUFPLHlCQUFTLEVBQUMsZUFBakI7QUFBQSx1Q0FDSTtBQUFHLDJCQUFTLEVBQUMsc0JBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUhKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkE5QkosZUFxQ0k7QUFBSyx1QkFBUyxFQUFDLFdBQWY7QUFBQSwyQ0FBNEI7QUFBTSx5QkFBUyxFQUFDLGNBQWhCO0FBQUEsdUNBQ3RCO0FBQUcsMkJBQVMsRUFBQztBQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFEc0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBNUIsZUFHSTtBQUFPLHlCQUFTLEVBQUMsZUFBakI7QUFBQSx1Q0FDSTtBQUFHLDJCQUFTLEVBQUMsc0JBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUhKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFyQ0osZUE0Q0k7QUFBSyx1QkFBUyxFQUFDLFdBQWY7QUFBQSwyQ0FBNEI7QUFBTSx5QkFBUyxFQUFDLGNBQWhCO0FBQUEsdUNBQ3RCO0FBQUcsMkJBQVMsRUFBQztBQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFEc0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBNUIsZUFHSTtBQUFPLHlCQUFTLEVBQUMsZUFBakI7QUFBQSx1Q0FDSTtBQUFHLDJCQUFTLEVBQUMsc0JBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUhKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkE1Q0osZUFtREk7QUFBSyx1QkFBUyxFQUFDLFdBQWY7QUFBQSwyQ0FBNEI7QUFBTSx5QkFBUyxFQUFDLGNBQWhCO0FBQUEsdUNBQ3RCO0FBQUcsMkJBQVMsRUFBQztBQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFEc0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBNUIsZUFHSTtBQUFPLHlCQUFTLEVBQUMsZUFBakI7QUFBQSx1Q0FDSTtBQUFHLDJCQUFTLEVBQUMsc0JBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUhKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFuREosZUEwREk7QUFBSyx1QkFBUyxFQUFDLFdBQWY7QUFBQSwyQ0FBNEI7QUFBTSx5QkFBUyxFQUFDLGNBQWhCO0FBQUEsdUNBQ3RCO0FBQUcsMkJBQVMsRUFBQztBQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFEc0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBNUIsZUFHSTtBQUFPLHlCQUFTLEVBQUMsZUFBakI7QUFBQSx1Q0FDSTtBQUFHLDJCQUFTLEVBQUMsc0JBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUhKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkExREosZUFpRUk7QUFBSyx1QkFBUyxFQUFDLFdBQWY7QUFBQSwyQ0FBNEI7QUFBTSx5QkFBUyxFQUFDLGNBQWhCO0FBQUEsdUNBQ3RCO0FBQUcsMkJBQVMsRUFBQztBQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFEc0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBNUIsZUFHSTtBQUFPLHlCQUFTLEVBQUMsZUFBakI7QUFBQSx1Q0FDSTtBQUFHLDJCQUFTLEVBQUMsc0JBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUhKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFqRUosZUF3RUk7QUFBSyx1QkFBUyxFQUFDLFdBQWY7QUFBQSwyQ0FBNEI7QUFBTSx5QkFBUyxFQUFDLGNBQWhCO0FBQUEsdUNBQ3RCO0FBQUcsMkJBQVMsRUFBQztBQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFEc0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBNUIsZUFHSTtBQUFPLHlCQUFTLEVBQUMsZUFBakI7QUFBQSx1Q0FDSTtBQUFHLDJCQUFTLEVBQUMsc0JBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUhKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkF4RUo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFwRko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREw7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURILG1CQURKO0FBK0tILENBaExEOztLQUFNQTtBQWtMTkEsV0FBVyxDQUFDSCxTQUFaLEdBQXdCQSxTQUF4QjtBQUNBRyxXQUFXLENBQUNGLFlBQVosR0FBMkJBLFlBQTNCO0FBRUEsK0RBQWVFLFdBQWYiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vY29tcG9uZW50cy9Ib21lL0hvd2l0d29ya3MuanMiLCJ3ZWJwYWNrOi8vX05fRS8uL2NvbXBvbmVudHMvSG9tZS9XaHljaG9vc2V1cy5qcyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnOyBcclxuaW1wb3J0IFByb3BUeXBlcyBmcm9tICdwcm9wLXR5cGVzJztcclxuaW1wb3J0IEltYWdlIGZyb20gJ25leHQvaW1hZ2UnXHJcbiBcclxuY29uc3QgcHJvcFR5cGVzID0ge307XHJcblxyXG5jb25zdCBkZWZhdWx0UHJvcHMgPSB7fTtcclxuIFxyXG5jb25zdCBIb3dpdHdvcmtzID0gKCkgPT4ge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgICA8PlxyXG4gICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2VjdGlvbi1mdWxsIHAtdDIwIHAtYjMwIGJnLXdoaXRlIGJnLXJlcGVhdCBzcXVhcmVfc2hhcGUyIGlubmVyLXBhZ2UtcGFkZGluZ1wiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb250YWluZXJcIj4gXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLWIyMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzZWMtdGl0bGUgdGV4dC1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC11cHBlcmNhc2Ugc2VwLWxpbmUtb25lXCI+SG93IEl0IFdvcmtzID88L2gyPiA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+IFxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2VjdGlvbi1jb250ZW50XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm93XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbC1tZC0zIGNvbC1zbS02IGhvdy13b3Jrc1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtaWNvbi1ib3gtd3JhcGVyIG0tYjMwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgaWNvbi1jb3VudC0yIHAtdDMwXCI+IDxzcGFuIGNsYXNzTmFtZT1cImljb24tY291bnQtbnVtYmVyIHAtbDUwIHAtcjIwXCI+MTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaWNvbi1tZCBpbmxpbmUtaWNvbiBtLWIxNSBwLWw0MCBwLXIzMCB0ZXh0LXByaW1hcnkgc2NhbGUtaW4tY2VudGVyXCI+IDxzcGFuIGNsYXNzTmFtZT1cImljb24tY2VsbFwiPjxJbWFnZSBzcmM9XCIvaW1hZ2VzL2ljb24vcmVxdWlyZW1lbnQxLnBuZ1wiIGFsdD1cIlwiIGxheW91dD0nZmlsbCcvPjwvc3Bhbj4gPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImljb24tY29udGVudCBjZW50ZXIgcC10MTAgcC1iMCBwLWwxMCBwLXIxMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJtdC10aWx0ZSBtLWIyNSB0ZXh0LWNlbnRlclwiPllvdXIgUmVxdWlyZW1lbnQ8L2g0PiA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sLW1kLTMgY29sLXNtLTYgaG93LXdvcmtzXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC1pY29uLWJveC13cmFwZXIgbS1iMzBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBpY29uLWNvdW50LTIgcC10MzBcIj4gPHNwYW4gY2xhc3NOYW1lPVwiaWNvbi1jb3VudC1udW1iZXIgcC1sNTAgcC1yMjBcIj4yPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJpY29uLW1kIGlubGluZS1pY29uIG0tYjE1IHAtbDQwIHAtcjMwIHRleHQtcHJpbWFyeSBzY2FsZS1pbi1jZW50ZXJcIj4gPHNwYW4gY2xhc3NOYW1lPVwiaWNvbi1jZWxsXCI+PEltYWdlIHNyYz1cIi9pbWFnZXMvaWNvbi9jb3N0ZXN0aW1hdGUxLnBuZ1wiIGFsdD1cIlwiIGxheW91dD0nZmlsbCcvPjwvc3Bhbj4gPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImljb24tY29udGVudCBwLXQxMCBwLWIwIHAtbDEwIHAtcjEwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cIm10LXRpbHRlIG0tYjI1IHRleHQtY2VudGVyXCI+Q29zdCBFc3RpbWF0aW9uPC9oND4gPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbC1tZC0zIGNvbC1zbS02IGhvdy13b3Jrc1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtaWNvbi1ib3gtd3JhcGVyIG0tYjMwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgaWNvbi1jb3VudC0yIHAtdDMwXCI+IDxzcGFuIGNsYXNzTmFtZT1cImljb24tY291bnQtbnVtYmVyICBwLWw1MCBwLXIyMFwiPjM8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImljb24tbWQgaW5saW5lLWljb24gbS1iMTUgcC1sNDAgcC1yMzAgdGV4dC1wcmltYXJ5IHNjYWxlLWluLWNlbnRlclwiPiA8c3BhbiBjbGFzc05hbWU9XCJpY29uLWNlbGxcIj48SW1hZ2Ugc3JjPVwiL2ltYWdlcy9pY29uL3NjaGVkdWxlMS5wbmdcIiBhbHQ9XCJcIiBsYXlvdXQ9J2ZpbGwnLz48L3NwYW4+IDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJpY29uLWNvbnRlbnQgY2VudGVyIHAtdDEwIHAtYjAgcC1sMTAgcC1yMTBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwibXQtdGlsdGUgbS1iMjUgdGV4dC1jZW50ZXJcIj5TY2hlZHVsZSBWaXNpdDwvaDQ+IDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb2wtbWQtMyBjb2wtc20tNiBob3ctd29ya3NcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LWljb24tYm94LXdyYXBlciBtLWIzMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIGljb24tY291bnQtMiBwLXQzMFwiPiA8c3BhbiBjbGFzc05hbWU9XCJpY29uLWNvdW50LW51bWJlciAgcC1sNTAgcC1yMjBcIj40PC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJpY29uLW1kIGlubGluZS1pY29uIG0tYjE1IHAtbDQwIHAtcjMwIHRleHQtcHJpbWFyeSBzY2FsZS1pbi1jZW50ZXJcIj4gPHNwYW4gY2xhc3NOYW1lPVwiaWNvbi1jZWxsXCI+PEltYWdlIHNyYz1cIi9pbWFnZXMvaWNvbi9leGN1dGUxLnBuZ1wiIGFsdD1cIlwiIGxheW91dD0nZmlsbCcvPjwvc3Bhbj4gPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImljb24tY29udGVudCBwLXQxMCBwLWIwIHAtbDEwIHAtcjEwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cIm10LXRpbHRlIG0tYjI1IHRleHQtY2VudGVyXCI+V29yayBFeGVjdXRpb248L2g0PiA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sLW1kLTMgY29sLXNtLTYgaG93LXdvcmtzXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC1pY29uLWJveC13cmFwZXIgbS1iMzBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBpY29uLWNvdW50LTIgcC10MzBcIj4gPHNwYW4gY2xhc3NOYW1lPVwiaWNvbi1jb3VudC1udW1iZXIgIHAtbDUwIHAtcjIwXCI+NTwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaWNvbi1tZCBpbmxpbmUtaWNvbiBtLWIxNSBwLWw0MCBwLXIzMCB0ZXh0LXByaW1hcnkgc2NhbGUtaW4tY2VudGVyXCI+IDxzcGFuIGNsYXNzTmFtZT1cImljb24tY2VsbFwiPjxJbWFnZSBzcmM9XCIvaW1hZ2VzL2ljb24vYXJjaGl0ZWN0dXJlMS5wbmdcIiBhbHQ9XCJcIiBsYXlvdXQ9J2ZpbGwnLz48L3NwYW4+IDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJpY29uLWNvbnRlbnQgcC10MTAgcC1iMCBwLWwxMCBwLXIxMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJtdC10aWx0ZSBtLWIyNSB0ZXh0LWNlbnRlclwiPlNhdGlzZmllZCBEZWxpdmVyeTwvaDQ+IDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2VjdGlvbi1mdWxsIG5lZWRzcm93XCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbnRhaW5lclwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgbmVlZHMtdGV4dFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8aDI+QWxsIHlvdXIgY29uc3RydWN0aW9uIG5lZWRzIHVuZGVyIG9uZSByb29mPC9oMj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJlc3RpbWF0ZVwiPiA8YSBocmVmPVwiXCIgZGF0YS10b2dnbGU9XCJtb2RhbFwiIGRhdGEtdGFyZ2V0PVwiI3dpdGgtZm9ybVwiPiBHZXQgYSBmcmVlIGVzdGltYXRlIG5vdzwvYT4gPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgIDwvPlxyXG4gICAgKTtcclxufVxyXG5cclxuSG93aXR3b3Jrcy5wcm9wVHlwZXMgPSBwcm9wVHlwZXM7XHJcbkhvd2l0d29ya3MuZGVmYXVsdFByb3BzID0gZGVmYXVsdFByb3BzO1xyXG4gXHJcblxyXG5leHBvcnQgZGVmYXVsdCBIb3dpdHdvcmtzOyIsImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7IFxyXG5pbXBvcnQgUHJvcFR5cGVzIGZyb20gJ3Byb3AtdHlwZXMnO1xyXG5pbXBvcnQgSW1hZ2UgZnJvbSAnbmV4dC9pbWFnZScgXHJcbiBcclxuY29uc3QgcHJvcFR5cGVzID0ge307XHJcblxyXG5jb25zdCBkZWZhdWx0UHJvcHMgPSB7fTtcclxuIFxyXG5jb25zdCBXaHljaG9vc2V1cyA9ICgpID0+IHtcclxuICAgIHJldHVybiAoXHJcbiAgICAgICAgPD5cclxuICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNlY3Rpb24tZnVsbCBvdmVybGF5LXdyYXBlciBiZy1jZW50ZXIgYmctcGFyYWxsYXggYmctY292ZXIgcC1iMjAgcC10NDAgeHMtaGlkZGVuIGJnLWdyYXktbGlnaHRcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29udGFpbmVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzZWMtdGl0bGUgdGV4dC1jZW50ZXIgcC1iMjBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtdXBwZXJjYXNlIHNlcC1saW5lLW9uZSB0ZXh0LWJsYWNrXCI+IFdoeSBDaG9vc2UgVXM8L2gyPiA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdyByb3ctcGItbWRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb2wtbWQtMTIgcGFkZGluZy0wXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbC1tZC00IHdoeWNob29zZS1ib3hcIj4gPHNwYW4gY2xhc3NOYW1lPVwid2h5Y2hvb3NlLWljb25cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxJbWFnZSAgYWx0PVwiSW50ZWdyYXRlZCBIb21lIGNvbnN0cnVjdGlvbiBhbmQgbW9uaXRvcmluZyBzZXJ2aWNlc1wiIHNyYz17XCIvaW1hZ2VzL2ljb24vcHJvZmVzc2lvbmFsLXNlcnZpY2UtaWNvbi1taW4ucG5nXCJ9IGxheW91dD1cImZpbGxcIi8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YXNpZGUgY2xhc3NOYW1lPVwid2h5Y2hvb3NlLXRleHRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGg1IGNsYXNzTmFtZT1cIm1hcmdpbi0wXCI+UHJvZmVzc2lvbmFsIFNlcnZpY2U8L2g1PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWxlZnQgZm9udC1saWdodFwiPuKAmEJlc3QgaW4gY2xhc3PigJkgc2VydmljZSBlbnN1cmVkIHdpdGggb3VyIGV4cGVyaWVuY2VkIGluLWhvdXNlIERlc2lnbiAmIENvbnN0cnVjdGlvbiB0ZWFtLiBDb21wbGV0ZSBIYXNzbGUtZnJlZSBFeHBlcmllbmNlIGZyb20gYmVnaW5uaW5nIHRvIGVuZC4gPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYXNpZGU+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sLW1kLTQgd2h5Y2hvb3NlLWJveFwiPiA8c3BhbiBjbGFzc05hbWU9XCJ3aHljaG9vc2UtaWNvblwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEltYWdlICBhbHQ9XCJXaWRlIHJhbmdlIG9mIENvbnN0cnVjdGlvbiBhbmQgbW9uaXRvcmluZyBzZXJ2aWNlc1wiIHNyYz1cIi9pbWFnZXMvaWNvbi9pbnN1cmVkLXdvcmstaWNvbi1taW4ucG5nXCIgbGF5b3V0PVwiZmlsbFwiLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxhc2lkZSBjbGFzc05hbWU9XCJ3aHljaG9vc2UtdGV4dFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aDUgY2xhc3NOYW1lPVwibWFyZ2luLTBcIj5JbnN1cmVkIFdvcms8L2g1PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWxlZnQgZm9udC1saWdodFwiPllvdXIgU3RydWN0dXJlIGlzIGluc3VyZWQgd2l0aCB1cy4gQW55IGlzc3VlLSBwb3N0IGNvbnN0cnVjdGlvbiwgbm8gbmVlZCB0byB3b3JyeS4gV2UgaGF2ZSB5b3VyIGJhY2s7IHdlIGFyZSBhbHdheXMgYXZhaWxhYmxlIGF0IGEgY2xpY2svY2FsbCBhd2F5LiA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9hc2lkZT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb2wtbWQtNCB3aHljaG9vc2UtYm94XCI+IDxzcGFuIGNsYXNzTmFtZT1cIndoeWNob29zZS1pY29uXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8SW1hZ2UgIGFsdD1cIkludGVncmF0ZWQgSG9tZSBjb25zdHJ1Y3Rpb24gYW5kIG1vbml0b3Jpbmcgc2VydmljZXNcIiBzcmM9XCIvaW1hZ2VzL2ljb24vZGlnaXRhbC10cmFja2luZy1pY29uLW1pbi5wbmdcIiBsYXlvdXQ9XCJmaWxsXCIvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGFzaWRlIGNsYXNzTmFtZT1cIndoeWNob29zZS10ZXh0XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoNSBjbGFzc05hbWU9XCJtYXJnaW4tMFwiPjEwMCUgdHJhbnNwYXJlbmN5IDwvaDU+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtbGVmdCBmb250LWxpZ2h0XCI+Tm8gSGlkZGVuIENoYXJnZXMsIEV2ZXJ5IGRldGFpbCBpcyBhcyBjbGVhciBhcyBhIGNyeXN0YWwuIFRvIGJyaW5nIGluIHRyYW5zcGFyZW5jeSBpcyBvbmUgb2Ygb3VyIGNvcmUgcHVycG9zZXMgb2YgZXhpc3RlbmNlLiA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9hc2lkZT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb2wtbWQtMTIgbXQtMTUgcGFkZGluZy0wXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbC1tZC00IHdoeWNob29zZS1ib3hcIj4gPHNwYW4gY2xhc3NOYW1lPVwid2h5Y2hvb3NlLWljb25cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxJbWFnZSAgYWx0PVwiRW5kIHRvIEVuZCBDb25zdHJ1Y3Rpb24gU2VydmljZXNcIiBzcmM9XCIvaW1hZ2VzL2ljb24vdHJhbnNwYXJlbmN5LWljb24tbWluLnBuZ1wiIGxheW91dD1cImZpbGxcIi8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YXNpZGUgY2xhc3NOYW1lPVwid2h5Y2hvb3NlLXRleHRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGg1IGNsYXNzTmFtZT1cIm1hcmdpbi0wXCI+RGlnaXRhbCBUcmFja2luZzwvaDU+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtbGVmdCBmb250LWxpZ2h0XCI+WW91IGNhbiBub3cgZGlnaXRhbGx5IHRyYWNrIHlvdXIgd29yayBwcm9ncmVzcywgd2l0aCBhIHNpbXBsZSBsb2dpbiB5b3UgYXJlIGVtcG93ZXJlZCB0byBjb250cm9sIGFuZCB0cmFjayBldmVyeSBpbmNoIG9mIHlvdXIgd29yayBzaXRlLiA8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9hc2lkZT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb2wtbWQtNCB3aHljaG9vc2UtYm94XCI+IDxzcGFuIGNsYXNzTmFtZT1cIndoeWNob29zZS1pY29uXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8SW1hZ2UgIGFsdD1cIkludGVncmF0ZWQgSG9tZSBjb25zdHJ1Y3Rpb24gYW5kIG1vbml0b3Jpbmcgc2VydmljZXNcIiBzcmM9XCIvaW1hZ2VzL2ljb24vcXVhbGl0eS1hc3N1cmFuY2UtaWNvbi1taW4ucG5nXCIgbGF5b3V0PVwiZmlsbFwiLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxhc2lkZSBjbGFzc05hbWU9XCJ3aHljaG9vc2UtdGV4dFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aDUgY2xhc3NOYW1lPVwibWFyZ2luLTBcIj5RdWFsaXR5IEFzc3VyYW5jZTwvaDU+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtbGVmdCBmb250LWxpZ2h0XCI+QmUgZW5zdXJlZCB3aXRoIHVzIHRoYXQgeW91IGhhdmUgdGhlIOKAmHJpZ2h0IHF1YWxpdHkgZm9yIHRoZSByaWdodCBwcmljZeKAmS4gTm8gbW9yZSBvdmVyIGNoYXJnaW5nIGFuZCBubyBtb3JlIHN1YnN0YW5kYXJkIHByb2R1Y3RzLjwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2FzaWRlPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbC1tZC00IHdoeWNob29zZS1ib3hcIj4gPHNwYW4gY2xhc3NOYW1lPVwid2h5Y2hvb3NlLWljb25cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxJbWFnZSAgYWx0PVwiV2lkZSByYW5nZSBvZiBDb25zdHJ1Y3Rpb24gYW5kIG1vbml0b3Jpbmcgc2VydmljZXNcIiBzcmM9XCIvaW1hZ2VzL2ljb24vb24tdGltZS1kZWxpdmVyeS1pY29uLnBuZ1wiIGxheW91dD1cImZpbGxcIi8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YXNpZGUgY2xhc3NOYW1lPVwid2h5Y2hvb3NlLXRleHRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGg1IGNsYXNzTmFtZT1cIm1hcmdpbi0wXCI+T24gdGltZSBEZWxpdmVyeTwvaDU+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtbGVmdCBmb250LWxpZ2h0XCI+TWlzc2luZyBkZWFkbGluZT8gTm90IGluIG91ciBkaWN0aW9uYXJ5LCB3ZSBhcmUg4oCYb24gdGltZSBldmVyeSB0aW1l4oCZLiBXZSB3aWxsIGVuc3VyZSDigJhvbiB0aW1lIGRlbGl2ZXJ54oCZIHRodXMgZW5zdXJpbmcgdGhhdCB0aGVyZSBhcmUgbm8gY29zdCBvdmVyIHJ1bnMuIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2FzaWRlPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbC1tZC0xMiBtdC0xNSBwYWRkaW5nLTBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sLW1kLTQgd2h5Y2hvb3NlLWJveFwiPiA8c3BhbiBjbGFzc05hbWU9XCJ3aHljaG9vc2UtaWNvblwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEltYWdlICBhbHQ9XCJXaWRlIHJhbmdlIG9mIENvbnN0cnVjdGlvbiBhbmQgbW9uaXRvcmluZyBzZXJ2aWNlc1wiIHNyYz1cIi9pbWFnZXMvaWNvbi9mbGV4aWJsZS5wbmdcIiBsYXlvdXQ9XCJmaWxsXCIvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGFzaWRlIGNsYXNzTmFtZT1cIndoeWNob29zZS10ZXh0XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxoNSBjbGFzc05hbWU9XCJtYXJnaW4tMFwiPkZsZXhpYmxlIFByaWNpbmcgTW9kZWxzPC9oNT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1sZWZ0IGZvbnQtbGlnaHRcIj5RdW90ZXMgdGhhdCBhcmUgdGFpbG9yZWQgZml0IHRvIHlvdXIgY2hvaWNlLiBOb3QgaGFwcHkgd2l0aCByaWdpZCBwcmljaW5nIG1vZGVscywgd2UgdW5kZXJzdGFuZCB5b3VyIGZydXN0cmF0aW9uLiBXaXRoIHVzLCB5b3UgY2FuIGN1c3RvbWl6ZSBhcyBwZXIgeW91ciBjb252ZW5pZW5jZS4gPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYXNpZGU+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sLW1kLTQgd2h5Y2hvb3NlLWJveFwiPiA8c3BhbiBjbGFzc05hbWU9XCJ3aHljaG9vc2UtaWNvblwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEltYWdlICBhbHQ9XCJXaWRlIHJhbmdlIG9mIENvbnN0cnVjdGlvbiBhbmQgbW9uaXRvcmluZyBzZXJ2aWNlc1wiIHNyYz1cIi9pbWFnZXMvaWNvbi9jdXJiaW5nLnBuZ1wiIGxheW91dD1cImZpbGxcIi8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YXNpZGUgY2xhc3NOYW1lPVwid2h5Y2hvb3NlLXRleHRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGg1IGNsYXNzTmFtZT1cIm1hcmdpbi0wXCI+Q3VyYmluZyBNYWxwcmFjdGljZXM8L2g1PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWxlZnQgZm9udC1saWdodFwiPldlIGhhdmUgcHV0IGEgY2hlY2sgb24gTWFscHJhY3RpY2VzLiBXaXRoIG91ciBuZXcgYWdlIHRlY2hub2xvZ3kgYXNzaXN0YW5jZSwgd2UgaGF2ZSBjdXJiZWQgYWxsIHRoZSBGcmF1ZHVsZW50IHByYWN0aWNlcy4gPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYXNpZGU+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sLW1kLTQgd2h5Y2hvb3NlLWJveFwiPiA8c3BhbiBjbGFzc05hbWU9XCJ3aHljaG9vc2UtaWNvblwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEltYWdlICBhbHQ9XCJXaWRlIHJhbmdlIG9mIENvbnN0cnVjdGlvbiBhbmQgbW9uaXRvcmluZyBzZXJ2aWNlc1wiIHNyYz1cIi9pbWFnZXMvaWNvbi9ub2Nvc3RydW5zLnBuZ1wiIGxheW91dD1cImZpbGxcIi8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YXNpZGUgY2xhc3NOYW1lPVwid2h5Y2hvb3NlLXRleHRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGg1IGNsYXNzTmFtZT1cIm1hcmdpbi0wXCI+Tm8gQ29zdCBPdmVyIFJ1bnM8L2g1PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWxlZnQgZm9udC1saWdodFwiPk9uY2Ugd2UgZmluYWxpemUgb24gYSBRdW90ZSwgdGhlcmUgaXMgbm8gZ29pbmcgYmFjay4gV2UgcHJvbWlzZSB5b3UgYSAxMDAlIE5vIENvc3QgT3ZlcnJ1biBQb2xpY3kuIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2FzaWRlPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm93IHJlYWQtbW9yZS1sZXNzXCIgZGF0YS1pZD1cIjBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb2wtc20tMTIgcmVhZC10b2dnbGUgcmVhZG1vcmVfc2VjXCIgZGF0YS1pZD0nMCc+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbC1tZC0xMlwiPiA8c3BhbiBjbGFzc05hbWU9XCJyZWFkbW9yZV9kc25cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpIGNsYXNzTmFtZT1cImZhIGZhLWxvbmctYXJyb3ctcmlnaHRcIj48L2k+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxhc2lkZSBjbGFzc05hbWU9XCJyZWFkbW9yZS10ZXh0XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtbGVmdCBmb250LWxpZ2h0XCI+UmVzaWRlbnRpYWwgQ29uc3RydWN0aW9uOiBDb21wbGV0ZSBlbmQgdG8gZW5kIGNvbnN0cnVjdGlvbiBzZXJ2aWNlcy0gYmVnaW5uaW5nIHdpdGggbGVnYWwgcGVybWlzc2lvbnMgZnJvbSBHb3Z0LiBhdXRob3JpdGllcyB0byBkZXNpZ25pbmcgKEFyY2hpdGVjdHVyZSBhbmQgU3RydWN0dXJhbCksIGV4ZWN1dGlvbiAoY29uc3RydWN0aW9uKSAsIEludGVyaW9ycyBhbmQgbW9uaXRvcmluZyBzZXJ2aWNlcyBmb3Ig4oCYeW91ciBkcmVhbSBob21l4oCZXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnIvPiBXZSB1bmRlcnN0YW5kIHRoZSBzdHJlc3MgYW5kIGNoYW9zIHRoYXQgZ29lcyB0aHJvdWdoIHRoZSBwcm9jZXNzIG9mIGJ1aWxkaW5nIHlvdXIgYmVhdXRpZnVsIGhvbWUsIGFsdGhvdWdoIHRoZSBlbmQgcmVzdWx0cyBhcmUgYW1hemluZywgdGhlIGNvbnN0cnVjdGlvbiBqb3VybmV5IGlzIGhlY3RpYyBhbmQgbm90IHZlcnkgcGxlYXNhbnQuIDwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2FzaWRlPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbC1tZC0xMlwiPiA8c3BhbiBjbGFzc05hbWU9XCJyZWFkbW9yZV9kc25cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpIGNsYXNzTmFtZT1cImZhIGZhLWxvbmctYXJyb3ctcmlnaHRcIj48L2k+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxhc2lkZSBjbGFzc05hbWU9XCJyZWFkbW9yZS10ZXh0XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtbGVmdCBmb250LWxpZ2h0XCI+IEluIHRvZGF54oCZcyBtb2Rlcm4gYW5kIGZhc3QgbGlmZSwgaG9tZS9hcGFydG1lbnQgY29uc3RydWN0aW9uIGhhcyBiZWNvbWUgYSB2ZXJ5IHRpbWUgY29uc3VtaW5nIHByb2Nlc3MgYnV0IHdlIGFyZSBoZXJlIHRvIGFzc2lzdCB5b3UgYnVpbGQgeW91ciBob21lL2FwYXJ0bWVudCBmYXN0ZXIsIHByZXR0aWVyIGFuZCBhbHNvIGVhc2llci48L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9hc2lkZT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb2wtbWQtMTJcIj4gPHNwYW4gY2xhc3NOYW1lPVwicmVhZG1vcmVfZHNuXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aSBjbGFzc05hbWU9XCJmYSBmYS1sb25nLWFycm93LXJpZ2h0XCI+PC9pPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YXNpZGUgY2xhc3NOYW1lPVwicmVhZG1vcmUtdGV4dFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWxlZnQgZm9udC1saWdodFwiPldlIGhhdmUgYnVpbHQgdGhpcyB3ZWIgcGxhY2UgZm9yIHlvdSBiYXNlZCBvbiA0VOKAmXMgKG91ciBwcmluY2lwbGVzKTwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2FzaWRlPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbC1tZC0xMlwiPiA8c3BhbiBjbGFzc05hbWU9XCJyZWFkbW9yZV9kc25cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpIGNsYXNzTmFtZT1cImZhIGZhLWxvbmctYXJyb3ctcmlnaHRcIj48L2k+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxhc2lkZSBjbGFzc05hbWU9XCJyZWFkbW9yZS10ZXh0XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtbGVmdCBmb250LWxpZ2h0XCI+VHJhbnNwYXJlbmN5ICh3ZSBhcmUgcHV0dGluZyBhbiBlbmQgdG8gZW5kbGVzcyBjaGVhdGluZyk8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9hc2lkZT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb2wtbWQtMTJcIj4gPHNwYW4gY2xhc3NOYW1lPVwicmVhZG1vcmVfZHNuXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aSBjbGFzc05hbWU9XCJmYSBmYS1sb25nLWFycm93LXJpZ2h0XCI+PC9pPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YXNpZGUgY2xhc3NOYW1lPVwicmVhZG1vcmUtdGV4dFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWxlZnQgZm9udC1saWdodFwiPlRpbWUgKE9uIHRpbWUgZGVsaXZlcnksIG5vIG1vcmUgY29zdCBvdmVyIHJ1bnMgZHVlIHRvIGRlbGF5IGluIGhvbWUgY29uc3RydWN0aW9uKTwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2FzaWRlPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbC1tZC0xMlwiPiA8c3BhbiBjbGFzc05hbWU9XCJyZWFkbW9yZV9kc25cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpIGNsYXNzTmFtZT1cImZhIGZhLWxvbmctYXJyb3ctcmlnaHRcIj48L2k+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxhc2lkZSBjbGFzc05hbWU9XCJyZWFkbW9yZS10ZXh0XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtbGVmdCBmb250LWxpZ2h0XCI+VHJhY2tpbmcgKHlvdSBzaG91bGQgYmUgYWJsZSB0byBjb250cm9sIGFuZCB0cmFjayBldmVyeSBiaXQgb2YgeW91ciBjb25zdHJ1Y3Rpb24sIGJlIGl0IG1hdGVyaWFsIG9yIHdvcmtmb3JjZSwgd2UgaGF2ZSBidWlsdCBuZWNlc3NhcnkgdG9vbHMgdG8gYXNzaXN0IHlvdSk8L3A+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9hc2lkZT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb2wtbWQtMTJcIj4gPHNwYW4gY2xhc3NOYW1lPVwicmVhZG1vcmVfZHNuXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aSBjbGFzc05hbWU9XCJmYSBmYS1sb25nLWFycm93LXJpZ2h0XCI+PC9pPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YXNpZGUgY2xhc3NOYW1lPVwicmVhZG1vcmUtdGV4dFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWxlZnQgZm9udC1saWdodFwiPlRlY2hub2xvZ3kgKFVzZSBvZiB0ZWNobm9sb2d5IGluIHBsYW5uaW5nLCBleGVjdXRpbmcgYW5kIG1vbml0b3Jpbmcgd2lsbCBpbmNyZWFzZSBlZmZpY2llbmN5LCByZWR1Y2UgY29zdCBhbmQgYWxsb3cgdXMgdG8gcHJvZHVjZSBncmVhdCByZXN1bHRzIGZvciB5b3UpPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYXNpZGU+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sLW1kLTEyXCI+IDxzcGFuIGNsYXNzTmFtZT1cInJlYWRtb3JlX2RzblwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGkgY2xhc3NOYW1lPVwiZmEgZmEtbG9uZy1hcnJvdy1yaWdodFwiPjwvaT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGFzaWRlIGNsYXNzTmFtZT1cInJlYWRtb3JlLXRleHRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1sZWZ0IGZvbnQtbGlnaHRcIj5XZSBhcmUgaGVyZSB0byBmYWNpbGl0YXRlIGFuZCBleGVjdXRlIGVuZCB0byBlbmQgc2VydmljZXMgb24geW91ciBiZWhhbGYgd2hpbGUgdGFraW5nIGludG8gYWNjb3VudCB5b3VyIGVhY2ggcHJlZmVyZW5jZSBpbiBkZXRhaWwgYW5kIG1ha2luZyBpdCB0aGUg4oCYYmVzdCBmcm9tIGJldHRlcuKAmSB3aGlsZSB5b3UgY2FuIG1vbml0b3IgZnJvbSB5b3VyIGhvbWUuPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYXNpZGU+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sLW1kLTEyXCI+IDxzcGFuIGNsYXNzTmFtZT1cInJlYWRtb3JlX2RzblwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGkgY2xhc3NOYW1lPVwiZmEgZmEtbG9uZy1hcnJvdy1yaWdodFwiPjwvaT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGFzaWRlIGNsYXNzTmFtZT1cInJlYWRtb3JlLXRleHRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1sZWZ0IGZvbnQtbGlnaHRcIj5Zb3UgY2FuIGJlIGFzc3VyZWQgd2l0aCB1cyB0aGF0IHlvdSBoYXZlIHRoZSByaWdodCBxdWFsaXR5IGZvciB0aGUgcmlnaHQgcHJpY2UsIHRoZSBiZXN0IGNvbnN1bHRhbnRzLCByaWdodCBwcm9mZXNzaW9uYWxzIGFuZCBpbiB0aGUgZW5kIOKAmHRoZSBiZXN0IGhvbWXigJkgYXNzdXJhbmNlPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYXNpZGU+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sLW1kLTEyXCI+IDxzcGFuIGNsYXNzTmFtZT1cInJlYWRtb3JlX2RzblwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGkgY2xhc3NOYW1lPVwiZmEgZmEtbG9uZy1hcnJvdy1yaWdodFwiPjwvaT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGFzaWRlIGNsYXNzTmFtZT1cInJlYWRtb3JlLXRleHRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1sZWZ0IGZvbnQtbGlnaHRcIj4gT3VyIGFpbSBpcyB0byBtYWtlIHRoaXMgd2ViIHBsYWNlIGFzIG9uZSBzdG9wIHNvbHV0aW9uIGZvciB5b3VyIGNvbXBsZXRlIGhvbWUgY29uc3RydWN0aW9uIGJlZ2lubmluZyB3aXRoIGFyY2hpdGVjdHVyZSAoSG9tZSBkZXNpZ25pbmcpIGFuZCBhc3Npc3RpbmcgeW91IHRvIGdldCBuZWNlc3NhcnkgYnVpbGRpbmcgcGVybWlzc2lvbnMgYXMgd2UgaGVscCB5b3UgQnVpbGQgeW91ciBob21lIC8gQnVpbGQgbXkgaG91c2UuPC9wPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYXNpZGU+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sLW1kLTEyXCI+IDxzcGFuIGNsYXNzTmFtZT1cInJlYWRtb3JlX2RzblwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGkgY2xhc3NOYW1lPVwiZmEgZmEtbG9uZy1hcnJvdy1yaWdodFwiPjwvaT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGFzaWRlIGNsYXNzTmFtZT1cInJlYWRtb3JlLXRleHRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1sZWZ0IGZvbnQtbGlnaHRcIj4gV2UgaGF2ZSBoaWdobHkgZXhwZXJpZW5jZWQgcHJvZmVzc2lvbmFscy9CdWlsZGluZyBjb250cmFjdG9ycyB0byBoZWxwIGFzc2lzdCB5b3UgYXQgYWxsIHN0YWdlcyB0aHJvdWdob3V0IHRoZSBwcm9jZXNzLjwvcD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2FzaWRlPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgXHJcbiAgICAgICAgPC8+XHJcbiAgICApO1xyXG59XHJcblxyXG5XaHljaG9vc2V1cy5wcm9wVHlwZXMgPSBwcm9wVHlwZXM7XHJcbldoeWNob29zZXVzLmRlZmF1bHRQcm9wcyA9IGRlZmF1bHRQcm9wcztcclxuIFxyXG5leHBvcnQgZGVmYXVsdCBXaHljaG9vc2V1cztcclxuXHJcblxyXG4iXSwibmFtZXMiOlsiUmVhY3QiLCJQcm9wVHlwZXMiLCJJbWFnZSIsInByb3BUeXBlcyIsImRlZmF1bHRQcm9wcyIsIkhvd2l0d29ya3MiLCJXaHljaG9vc2V1cyJdLCJzb3VyY2VSb290IjoiIn0=